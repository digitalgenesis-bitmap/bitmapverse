"""Independent implementation of the same_sat_latest_v0.1 resolver.

Built solely from blind/v0.1/CONTRACT.md, case.json, PACKAGE_MANIFEST.json and
the two fixtures. Standard library only. See AMBIGUITIES.md for every
interpretive decision made while translating the prose contract into code.
"""

from __future__ import annotations

import hashlib
import json
import re

EXPECTED_SCHEMA = "bitmapverse.same_sat_latest.fixture.v0.1"
EXPECTED_VERSION = "0.1.0"
EXPECTED_STATUS = "experimental"
EXPECTED_SCOPE = "convención interna de Bitmapverse v0.1"
EXPECTED_RESOLVER = "same_sat_latest_v0.1"

HEX64_RE = re.compile(r"^[0-9a-f]{64}$")


class ResolverRejected(Exception):
    """Raised when a fixture fails a mandatory contract validation."""


def _is_hex64(value) -> bool:
    return isinstance(value, str) and bool(HEX64_RE.match(value))


def _sha256_hex(data: str) -> str:
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


def _require(condition: bool, reason: str) -> None:
    if not condition:
        raise ResolverRejected(reason)


def _validate_identity(fixture: dict) -> None:
    _require(
        fixture.get("schema") == EXPECTED_SCHEMA
        and fixture.get("version") == EXPECTED_VERSION
        and fixture.get("status") == EXPECTED_STATUS
        and fixture.get("scope") == EXPECTED_SCOPE
        and fixture.get("resolver") == EXPECTED_RESOLVER,
        "schema/version/status/scope/resolver do not match v0.1",
    )


def _validate_district_name(fixture: dict) -> None:
    district = fixture.get("district")
    district_name = fixture.get("district_name")
    _require(
        isinstance(district, int)
        and isinstance(district_name, str)
        and district_name == f"{district}.bitmap",
        "district_name does not match <district>.bitmap",
    )


def _validate_snapshot_and_sat_format(fixture: dict) -> None:
    snapshot_height = fixture.get("snapshot_height")
    snapshot_block_hash = fixture.get("snapshot_block_hash")
    sat = fixture.get("sat")
    _require(
        isinstance(snapshot_height, int)
        and not isinstance(snapshot_height, bool)
        and snapshot_height >= 0,
        "invalid snapshot_height format",
    )
    _require(_is_hex64(snapshot_block_hash), "invalid snapshot_block_hash format")
    _require(
        isinstance(sat, int) and not isinstance(sat, bool) and sat >= 0,
        "invalid sat format",
    )


def _validate_candidates_exist(fixture: dict) -> list:
    candidates = fixture.get("candidates")
    _require(isinstance(candidates, list) and len(candidates) > 0, "no candidates present")
    return candidates


def _validate_original_present(fixture: dict, candidates: list) -> dict:
    original_id = fixture.get("original_inscription_id")
    matches = [c for c in candidates if c.get("inscription_id") == original_id]
    _require(len(matches) == 1, "original inscription missing from candidates")
    original = matches[0]
    _require(
        original.get("declared_content") == fixture.get("district_name"),
        "original candidate declared_content does not match district",
    )
    return original


def _validate_candidate_sats(fixture: dict, candidates: list) -> None:
    sat = fixture.get("sat")
    for c in candidates:
        _require(c.get("sat") == sat, "candidate belongs to a different sat")


def _validate_inscription_ids(candidates: list) -> None:
    for c in candidates:
        cp = c.get("canonical_position") or {}
        txid = cp.get("transaction_id")
        idx = cp.get("inscription_index")
        expected = f"{txid}i{idx}" if txid is not None and idx is not None else None
        _require(
            expected is not None and c.get("inscription_id") == expected,
            "inscription_id does not match transaction_id/inscription_index",
        )


def _validate_canonical_positions(candidates: list) -> None:
    for c in candidates:
        cp = c.get("canonical_position")
        _require(isinstance(cp, dict), "candidate missing canonical_position")
        for key in ("block_height", "transaction_index", "inscription_index"):
            value = cp.get(key)
            _require(
                isinstance(value, int) and not isinstance(value, bool) and value >= 0,
                f"canonical_position.{key} missing or negative",
            )
        _require(_is_hex64(cp.get("block_hash")), "canonical_position.block_hash invalid format")
        _require(isinstance(cp.get("transaction_id"), str) and len(cp["transaction_id"]) > 0,
                  "canonical_position.transaction_id missing")


def _validate_unique_tuples(candidates: list) -> None:
    seen = set()
    for c in candidates:
        cp = c["canonical_position"]
        tup = (cp["block_height"], cp["transaction_index"], cp["inscription_index"])
        _require(tup not in seen, "two candidates share the same canonical tuple")
        seen.add(tup)


def _validate_snapshot_height_hash_agreement(fixture: dict, candidates: list) -> None:
    snapshot_height = fixture["snapshot_height"]
    snapshot_block_hash = fixture["snapshot_block_hash"]
    for c in candidates:
        cp = c["canonical_position"]
        if cp["block_height"] == snapshot_height:
            _require(
                cp["block_hash"] == snapshot_block_hash,
                "candidate at snapshot_height declares a different block_hash",
            )


def _validate_content_hashes(candidates: list) -> None:
    for c in candidates:
        _require(_is_hex64(c.get("content_sha256")), "candidate missing valid content_sha256")


def _validate_enumeration(fixture: dict, candidates: list) -> None:
    enumeration = fixture.get("candidate_enumeration")
    _require(isinstance(enumeration, dict), "candidate_enumeration missing")

    _require(enumeration.get("complete_through_snapshot") is True,
              "enumeration does not declare itself complete")
    _require(enumeration.get("reported_more") is False,
              "enumeration reports more pages")

    response_body = enumeration.get("response_body")
    _require(isinstance(response_body, str), "enumeration response_body missing")
    _require(
        _is_hex64(enumeration.get("response_sha256"))
        and _sha256_hex(response_body) == enumeration["response_sha256"],
        "enumeration response_sha256 is incorrect",
    )

    try:
        parsed = json.loads(response_body)
    except json.JSONDecodeError as exc:
        raise ResolverRejected("enumeration response_body is not valid JSON") from exc

    reported_ids = parsed.get("ids")
    _require(isinstance(reported_ids, list), "enumeration response_body missing ids")
    candidate_ids = [c.get("inscription_id") for c in candidates]
    _require(
        set(reported_ids) == set(candidate_ids) and len(reported_ids) == len(candidate_ids),
        "enumeration does not match candidates exactly",
    )
    _require(
        enumeration.get("reported_count") == len(candidate_ids),
        "enumeration reported_count does not match candidate count",
    )


def _validate_ord_manifest(fixture: dict) -> None:
    enumeration = fixture["candidate_enumeration"]
    manifest = fixture.get("source_manifest") or {}
    ord_manifest = manifest.get("ord")
    _require(isinstance(ord_manifest, dict), "source_manifest.ord missing")
    _require(
        ord_manifest.get("enumeration_response_sha256") == enumeration.get("response_sha256"),
        "Ord manifest does not reference the same enumeration hash",
    )


def _validate_opi_manifest(fixture: dict) -> None:
    manifest = fixture.get("source_manifest") or {}
    opi = manifest.get("opi")
    _require(isinstance(opi, dict), "source_manifest.opi missing")

    district = fixture["district"]
    query = opi.get("query")
    expected_query = f"/v1/bitmap/get_inscription_id_of_bitmap?bitmap_number={district}"
    _require(query == expected_query, "OPI query does not correspond to the district")

    response_status = opi.get("response_status")
    response_sha256 = opi.get("response_sha256")
    not_captured = isinstance(response_status, str) and response_status.startswith("not_captured")
    _require(
        (response_sha256 is None and not_captured)
        or (response_sha256 is not None and not not_captured and _is_hex64(response_sha256)),
        "OPI manifest is internally inconsistent",
    )


def _select(fixture: dict, candidates: list) -> dict:
    snapshot_height = fixture["snapshot_height"]
    eligible = [c for c in candidates if c["canonical_position"]["block_height"] <= snapshot_height]
    _require(len(eligible) > 0, "no eligible candidate at or before snapshot_height")

    def sort_key(c):
        cp = c["canonical_position"]
        return (cp["block_height"], cp["transaction_index"], cp["inscription_index"])

    eligible.sort(key=sort_key)
    return eligible[-1]


def resolve(fixture: dict) -> dict:
    """Validate a fixture and resolve the selected inscription.

    Raises ResolverRejected if any mandatory validation from CONTRACT.md fails.
    """
    _validate_identity(fixture)
    _validate_district_name(fixture)
    _validate_snapshot_and_sat_format(fixture)
    candidates = _validate_candidates_exist(fixture)
    _validate_original_present(fixture, candidates)
    _validate_candidate_sats(fixture, candidates)
    _validate_inscription_ids(candidates)
    _validate_canonical_positions(candidates)
    _validate_unique_tuples(candidates)
    _validate_snapshot_height_hash_agreement(fixture, candidates)
    _validate_content_hashes(candidates)
    _validate_enumeration(fixture, candidates)
    _validate_ord_manifest(fixture)
    _validate_opi_manifest(fixture)

    selected = _select(fixture, candidates)

    return {
        "district": fixture["district_name"],
        "original_inscription_id": fixture["original_inscription_id"],
        "sat": fixture["sat"],
        "selected_inscription_id": selected["inscription_id"],
        "selected_content_sha256": selected["content_sha256"],
        "selected_canonical_position": selected["canonical_position"],
        "snapshot_height": fixture["snapshot_height"],
        "snapshot_block_hash": fixture["snapshot_block_hash"],
        "candidate_count": len(candidates),
        "status": EXPECTED_STATUS,
        "scope": EXPECTED_SCOPE,
        "warnings": fixture.get("warnings", []),
        "provenance": fixture.get("provenance", []),
    }


def resolve_fixture_file(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as fh:
        fixture = json.load(fh)
    return resolve(fixture)


def main() -> None:
    import sys

    for path in sys.argv[1:]:
        try:
            result = resolve_fixture_file(path)
            print(json.dumps(result, ensure_ascii=False, indent=2))
        except ResolverRejected as exc:
            print(json.dumps({"rejected": True, "reason": str(exc)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
