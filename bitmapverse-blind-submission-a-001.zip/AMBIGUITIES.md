# AMBIGUITIES.md

Interpretive decisions made while turning `CONTRACT.md` (prose) into
`resolver.py` (code). Recorded before any comparison against the reserved
oracle, per `TASK.md`'s closure clause.

## 1. Literal values for "no coinciden con v0.1"

The contract says the fixture must be rejected if "el schema, versión,
estado, alcance o resolver no coinciden con v0.1", but never states the
literal expected strings anywhere in `CONTRACT.md` itself. I derived the
five expected constants from the values that are identical across both
provided fixtures:

- `schema == "bitmapverse.same_sat_latest.fixture.v0.1"`
- `version == "0.1.0"`
- `status == "experimental"`
- `scope == "convención interna de Bitmapverse v0.1"`
- `resolver == "same_sat_latest_v0.1"`

Both fixtures agree on all five, which is consistent with this reading, but
a hypothetical third fixture using a different (still "v0.1"-ish) string for
any of these would be rejected by this implementation even if the intended
rule were looser (e.g. only checking `version.startswith("0.1")`).

## 2. Which fields are "hashes" subject to format validation

"El snapshot, el sat o un hash tienen formato inválido" names "un hash"
generically. I applied 64-lowercase-hex validation to every field that is
named or suffixed `*_hash` / `*_sha256` and is not explicitly nullable by
its own semantics: `snapshot_block_hash`, `canonical_position.block_hash`,
`content_sha256`, `candidate_enumeration.response_sha256`. I did **not**
require `source_manifest.opi.api_source_sha256` to pass this check as a
rejection condition on its own, since the contract's validation list never
mentions the OPI manifest's internal hash fields except through the
"consulta OPI... manifiesto es inconsistente" clause (see §6). I left
`api_source_sha256` unvalidated as a deliberate scope decision.

## 3. Format bounds for `sat`

I validated `sat` as a non-negative integer only. The contract does not
state the maximum sat number (~2.1 quadrillion), so I did not enforce an
upper bound. A stricter reading might reject sats beyond the known supply
ceiling; I chose the more permissive interpretation since the contract text
gives no explicit ceiling.

## 4. `district` field in the output: name vs. number

The output spec lists a bare `district` field. The fixture carries both an
integer `district` and a string `district_name`. Since the contract's own
validation language treats "el nombre del District" (`<district>.bitmap`)
as the canonical identity being checked, I emit the **string** form
(`"507999.bitmap"`) as `district` in the result. An equally defensible
reading would emit the bare integer instead.

## 5. "No existe ningún candidato" vs. "ningún candidato elegible"

The contract lists "no existe ningún candidato" as a rejection reason but
never explicitly states what happens if candidates exist but none are
eligible (`block_height <= snapshot_height`) — i.e. all inscriptions on the
sat happened after the snapshot. I treat this as an implicit extension of
the same rule (reject: "no eligible candidate at or before
snapshot_height"), since the canonical-order selection is undefined
otherwise and the contract elsewhere guarantees "si solamente existe la
original, se selecciona la original" (implying the original — necessarily
pre-snapshot in the fixtures provided — is expected to always be eligible).

## 6. OPI manifest "inconsistency" check

"La consulta OPI no corresponde al District o su manifiesto es
inconsistente" has two clauses. The first (`query` must reference the
district) I implemented literally: `query ==
f"/v1/bitmap/get_inscription_id_of_bitmap?bitmap_number={district}"`.

The second ("manifiesto es inconsistente") is not defined anywhere in the
contract. I interpreted it as an internal consistency check between
`response_status` and `response_sha256`: if `response_status` starts with
`"not_captured"`, `response_sha256` must be `null`; otherwise
`response_sha256` must be present and a valid hex-64 hash. Both provided
fixtures satisfy this (status `not_captured_no_public_instance`, hash
`null`). This is the weakest-evidence interpretation I could construct from
the field names alone — a different implementation might check something
else entirely (e.g. cross-referencing `opi.commit` against a known-good
commit list), which is exactly the kind of divergence this experiment is
meant to surface.

## 7. Enumeration "coincide exactamente con los candidatos"

I required the JSON-parsed `ids` list inside `response_body` to have
exactly the same **set** of inscription IDs as `candidates` (order-
independent), plus `reported_count == len(candidates) == len(ids)`. The
contract does not say whether ordering inside `response_body` must match
candidate array order; I did not enforce ordering, only set equality and
count equality.

## 8. Enumeration hash validated by recomputation, not by trusting the field

`candidate_enumeration.response_sha256` is checked against a **freshly
computed** `sha256(response_body)`, rather than merely checking the field
is a well-formed hex string. The contract's "tiene un hash incorrecto"
clause reads as requiring the hash to actually be correct, not merely
present, so I treat a well-formed-but-wrong hash as a rejection.

## 9. Canonical-position "enteros negativos" scope

"Falta una posición canónica o contiene enteros negativos" — I applied the
non-negative-integer check to `block_height`, `transaction_index`, and
`inscription_index` (the three integer fields inside `canonical_position`),
not to fields elsewhere in the fixture (e.g. `content_length`,
`inscription_number`), since those are outside `canonical_position` and the
clause is scoped to "una posición canónica".

## 10. `test_resolver.py` is self-contained (fixtures embedded, not read from disk)

`TASK.md` lists exactly five deliverables and does not include the
`fixtures/` directory among them. To keep `test_resolver.py` runnable from
just the two delivered files (`resolver.py` + `test_resolver.py`) without
requiring the recipient to also have the original package on disk, I
embedded verbatim copies of both fixtures as Python literals in the test
file rather than reading them from `fixtures/*.json` by relative path. This
is a packaging choice, not a contract interpretation, but I record it here
since it affects how the deliverable should be run.

## 11. Order of validation checks is unspecified

`CONTRACT.md` lists twelve rejection conditions as an unordered bullet
list. My implementation checks them in the sequence they appear in the
contract text (identity → district name → snapshot/sat format → candidates
exist → original present → sat consistency → inscription-id/position
consistency → uniqueness → snapshot-height agreement → content hash →
enumeration → Ord manifest → OPI manifest), then performs selection last.
Since `resolve()` raises on the first failing check, a fixture violating
multiple rules simultaneously will report only the first one encountered in
this order. Neither fixture in the package triggers more than zero
violations, so this ordering choice does not affect `result.json`, but it
would affect the specific rejection reason reported for a multiply-invalid
fixture.
