"""Tests for resolver.py, derived from blind/v0.1/CONTRACT.md.

Fixture data is embedded verbatim (copied from the two authorized fixture
files) so this test file is self-contained and needs no external path.
Rejection-path tests mutate a deep copy of a valid fixture to violate exactly
one clause of CONTRACT.md's "Validaciones obligatorias" list.
"""

import copy
import json
import unittest

from resolver import ResolverRejected, resolve

FIXTURE_507999 = {
    "schema": "bitmapverse.same_sat_latest.fixture.v0.1",
    "version": "0.1.0",
    "status": "experimental",
    "scope": "convención interna de Bitmapverse v0.1",
    "fixture_id": "507999-at-959531",
    "district": 507999,
    "district_name": "507999.bitmap",
    "resolver": "same_sat_latest_v0.1",
    "snapshot_height": 959531,
    "snapshot_block_hash": "000000000000000000008d94f099ecc2e05da35160cabb2c3d6332db0130269e",
    "original_inscription_id": "2505f63d9bf8aad28ddfc7b6dc49e0fa38a3196f7d159f29235585d3fd6958d0i0",
    "sat": 1931628970942295,
    "candidates": [
        {
            "inscription_id": "16c5bedd987167d6d5e7a8097d2dacb22ac112eaa0d6d5b1ff030578e75f9675i0",
            "inscription_number": 126975376,
            "sat": 1931628970942295,
            "content_type": "text/html;charset=utf-8",
            "content_length": 29280,
            "content_sha256": "177e29dbaaf7cb10440535b4da29cd669332a336779dd96f0b0a408d4909775f",
            "canonical_position": {
                "block_height": 959318,
                "block_hash": "00000000000000000000fccfe411b1b15ebaf223f31c68ffab02eadb4fa3d06c",
                "transaction_id": "16c5bedd987167d6d5e7a8097d2dacb22ac112eaa0d6d5b1ff030578e75f9675",
                "transaction_index": 2781,
                "inscription_index": 0,
            },
        },
        {
            "inscription_id": "2505f63d9bf8aad28ddfc7b6dc49e0fa38a3196f7d159f29235585d3fd6958d0i0",
            "inscription_number": 12933248,
            "sat": 1931628970942295,
            "content_type": "text/plain",
            "content_length": 13,
            "content_sha256": "09e9c97cb00ea968d94a1cc791e1474ed2727872bdbed18d55a4798719a3e1b2",
            "declared_content": "507999.bitmap",
            "canonical_position": {
                "block_height": 795180,
                "block_hash": "0000000000000000000473d19b8d4b5c27e07e35f567b0c3e77f0af3922fd06a",
                "transaction_id": "2505f63d9bf8aad28ddfc7b6dc49e0fa38a3196f7d159f29235585d3fd6958d0",
                "transaction_index": 3849,
                "inscription_index": 0,
            },
        },
    ],
    "candidate_enumeration": {
        "source": "ordinals.com",
        "endpoint": "https://ordinals.com/r/sat/1931628970942295",
        "observed_at": "2026-07-30",
        "reported_count": 2,
        "reported_more": False,
        "response_body": '{"ids":["2505f63d9bf8aad28ddfc7b6dc49e0fa38a3196f7d159f29235585d3fd6958d0i0","16c5bedd987167d6d5e7a8097d2dacb22ac112eaa0d6d5b1ff030578e75f9675i0"],"more":false,"page":0}',
        "response_sha256": "91aeb721b2293f01f136827c6ab7e3139766ff6ffaec338e415f81ab60bfe74d",
        "complete_through_snapshot": True,
    },
    "source_manifest": {
        "opi": {
            "implementation": "https://github.com/bestinslot-xyz/OPI",
            "commit": "da24fb6cf4c2ef3f99d030ea2ef18ba9099b0633",
            "api_source_sha256": "aa0d85488de71d5b4cb31ae1953177c111560eeb1242a64f0761962b8a6ac4a0",
            "query": "/v1/bitmap/get_inscription_id_of_bitmap?bitmap_number=507999",
            "observed_at": "2026-07-30",
            "response_sha256": None,
            "response_status": "not_captured_no_public_instance",
        },
        "ord": {
            "implementation": "ord server via ordinals.com",
            "version": "not_exposed_by_public_server",
            "observed_at": "2026-07-30",
            "enumeration_response_sha256": "91aeb721b2293f01f136827c6ab7e3139766ff6ffaec338e415f81ab60bfe74d",
        },
    },
    "provenance": [
        "https://ordinals.com/r/inscription/2505f63d9bf8aad28ddfc7b6dc49e0fa38a3196f7d159f29235585d3fd6958d0i0",
        "https://ordinals.com/r/inscription/16c5bedd987167d6d5e7a8097d2dacb22ac112eaa0d6d5b1ff030578e75f9675i0",
        "https://ordinals.com/r/blockhash/959531",
        "https://mempool.space/api/block-height/795180",
        "https://mempool.space/api/block-height/959318",
    ],
    "warnings": [
        "La regla es experimental y no constituye un estándar universal de Bitmap.",
        "La selección de contenido no demuestra que el código sea seguro.",
        "La resolución no establece autoridad actual ni vínculo con Names.bitmap.",
        "La implementación OPI quedó fijada por commit, pero no se capturó una respuesta de una instancia pública.",
    ],
}

FIXTURE_7187 = {
    "schema": "bitmapverse.same_sat_latest.fixture.v0.1",
    "version": "0.1.0",
    "status": "experimental",
    "scope": "convención interna de Bitmapverse v0.1",
    "fixture_id": "7187-at-959531",
    "district": 7187,
    "district_name": "7187.bitmap",
    "resolver": "same_sat_latest_v0.1",
    "snapshot_height": 959531,
    "snapshot_block_hash": "000000000000000000008d94f099ecc2e05da35160cabb2c3d6332db0130269e",
    "original_inscription_id": "50123b2d404f0ca8d97d07a98bd897d748b2db3d611496fa4eb1288171e8ea61i0",
    "sat": 1598464714258840,
    "candidates": [
        {
            "inscription_id": "4fff62f3c3754d62f35e0fe70b7d7ae6ad5715b35029e1cc2ff8588ea502d65di0",
            "inscription_number": 126984512,
            "sat": 1598464714258840,
            "content_type": "text/plain;charset=utf-8",
            "content_length": 37,
            "content_sha256": "582234b818783e0e5a31a5ea4b6694f87ac142b5bc776ee803a937bb5815a74d",
            "canonical_position": {
                "block_height": 959518,
                "block_hash": "00000000000000000001f191db40b78d11f9c1844c95acb8b5986015e27587f0",
                "transaction_id": "4fff62f3c3754d62f35e0fe70b7d7ae6ad5715b35029e1cc2ff8588ea502d65d",
                "transaction_index": 162,
                "inscription_index": 0,
            },
        },
        {
            "inscription_id": "50123b2d404f0ca8d97d07a98bd897d748b2db3d611496fa4eb1288171e8ea61i0",
            "inscription_number": 12018005,
            "sat": 1598464714258840,
            "content_type": "text/plain;charset=utf-8",
            "content_length": 11,
            "content_sha256": "386de928b5be77decadf920f5648e8228928ada6375006a685e5ebbd88aae8d4",
            "declared_content": "7187.bitmap",
            "canonical_position": {
                "block_height": 794524,
                "block_hash": "000000000000000000050fb165d217c2984c9297fe34945c3203f53419cee291",
                "transaction_id": "50123b2d404f0ca8d97d07a98bd897d748b2db3d611496fa4eb1288171e8ea61",
                "transaction_index": 1146,
                "inscription_index": 0,
            },
        },
        {
            "inscription_id": "a40f8c3af2058c9178c758d500f16f314ef2384fcf8a28a233ceda5ec7fd698ei0",
            "inscription_number": 126985258,
            "sat": 1598464714258840,
            "content_type": "text/plain;charset=utf-8",
            "content_length": 37,
            "content_sha256": "582234b818783e0e5a31a5ea4b6694f87ac142b5bc776ee803a937bb5815a74d",
            "canonical_position": {
                "block_height": 959531,
                "block_hash": "000000000000000000008d94f099ecc2e05da35160cabb2c3d6332db0130269e",
                "transaction_id": "a40f8c3af2058c9178c758d500f16f314ef2384fcf8a28a233ceda5ec7fd698e",
                "transaction_index": 2381,
                "inscription_index": 0,
            },
        },
    ],
    "candidate_enumeration": {
        "source": "ordinals.com",
        "endpoint": "https://ordinals.com/r/sat/1598464714258840",
        "observed_at": "2026-07-30",
        "reported_count": 3,
        "reported_more": False,
        "response_body": '{"ids":["50123b2d404f0ca8d97d07a98bd897d748b2db3d611496fa4eb1288171e8ea61i0","4fff62f3c3754d62f35e0fe70b7d7ae6ad5715b35029e1cc2ff8588ea502d65di0","a40f8c3af2058c9178c758d500f16f314ef2384fcf8a28a233ceda5ec7fd698ei0"],"more":false,"page":0}',
        "response_sha256": "e60793c18caeea659507e837f2ca8b3cd68eb254e8d8eee6d5ab798a3af18727",
        "complete_through_snapshot": True,
    },
    "source_manifest": {
        "opi": {
            "implementation": "https://github.com/bestinslot-xyz/OPI",
            "commit": "da24fb6cf4c2ef3f99d030ea2ef18ba9099b0633",
            "api_source_sha256": "aa0d85488de71d5b4cb31ae1953177c111560eeb1242a64f0761962b8a6ac4a0",
            "query": "/v1/bitmap/get_inscription_id_of_bitmap?bitmap_number=7187",
            "observed_at": "2026-07-30",
            "response_sha256": None,
            "response_status": "not_captured_no_public_instance",
        },
        "ord": {
            "implementation": "ord server via ordinals.com",
            "version": "not_exposed_by_public_server",
            "observed_at": "2026-07-30",
            "enumeration_response_sha256": "e60793c18caeea659507e837f2ca8b3cd68eb254e8d8eee6d5ab798a3af18727",
        },
    },
    "provenance": [
        "https://ordinals.com/r/inscription/50123b2d404f0ca8d97d07a98bd897d748b2db3d611496fa4eb1288171e8ea61i0",
        "https://ordinals.com/r/inscription/4fff62f3c3754d62f35e0fe70b7d7ae6ad5715b35029e1cc2ff8588ea502d65di0",
        "https://ordinals.com/r/inscription/a40f8c3af2058c9178c758d500f16f314ef2384fcf8a28a233ceda5ec7fd698ei0",
        "https://ordinals.com/r/blockhash/959531",
        "https://mempool.space/api/block-height/794524",
        "https://mempool.space/api/block-height/959518",
        "https://mempool.space/api/block-height/959531",
    ],
    "warnings": [
        "La regla es experimental y no constituye un estándar universal de Bitmap.",
        "El linaje observado no demuestra ejecución ni coordinación de agentes.",
        "La selección no valida afirmaciones externas sobre los contenidos.",
        "La implementación OPI quedó fijada por commit, pero no se capturó una respuesta de una instancia pública.",
    ],
}


def mutated(base, mutate_fn):
    fixture = copy.deepcopy(base)
    mutate_fn(fixture)
    return fixture


class HappyPathTests(unittest.TestCase):
    def test_507999_selects_latest_eligible_candidate(self):
        result = resolve(FIXTURE_507999)
        self.assertEqual(
            result["selected_inscription_id"],
            "16c5bedd987167d6d5e7a8097d2dacb22ac112eaa0d6d5b1ff030578e75f9675i0",
        )
        self.assertEqual(result["candidate_count"], 2)
        self.assertEqual(result["district"], "507999.bitmap")
        self.assertEqual(result["status"], "experimental")
        self.assertEqual(result["scope"], "convención interna de Bitmapverse v0.1")

    def test_7187_selects_candidate_at_snapshot_height(self):
        result = resolve(FIXTURE_7187)
        self.assertEqual(
            result["selected_inscription_id"],
            "a40f8c3af2058c9178c758d500f16f314ef2384fcf8a28a233ceda5ec7fd698ei0",
        )
        self.assertEqual(result["candidate_count"], 3)

    def test_only_original_present_selects_original(self):
        import hashlib

        def mutate(f):
            f["candidates"] = [f["candidates"][1]]
            body = '{"ids":["2505f63d9bf8aad28ddfc7b6dc49e0fa38a3196f7d159f29235585d3fd6958d0i0"],"more":false,"page":0}'
            f["candidate_enumeration"]["response_body"] = body
            digest = hashlib.sha256(body.encode("utf-8")).hexdigest()
            f["candidate_enumeration"]["response_sha256"] = digest
            f["candidate_enumeration"]["reported_count"] = 1
            f["source_manifest"]["ord"]["enumeration_response_sha256"] = digest

        fixture = mutated(FIXTURE_507999, mutate)
        result = resolve(fixture)
        self.assertEqual(
            result["selected_inscription_id"],
            FIXTURE_507999["original_inscription_id"],
        )


class ValidationRejectionTests(unittest.TestCase):
    def assert_rejected(self, fixture):
        with self.assertRaises(ResolverRejected):
            resolve(fixture)

    def test_rejects_mismatched_schema(self):
        self.assert_rejected(mutated(FIXTURE_507999, lambda f: f.__setitem__("schema", "wrong")))

    def test_rejects_mismatched_version(self):
        self.assert_rejected(mutated(FIXTURE_507999, lambda f: f.__setitem__("version", "0.2.0")))

    def test_rejects_mismatched_status(self):
        self.assert_rejected(mutated(FIXTURE_507999, lambda f: f.__setitem__("status", "final")))

    def test_rejects_mismatched_scope(self):
        self.assert_rejected(mutated(FIXTURE_507999, lambda f: f.__setitem__("scope", "other")))

    def test_rejects_mismatched_resolver(self):
        self.assert_rejected(mutated(FIXTURE_507999, lambda f: f.__setitem__("resolver", "other_v0.1")))

    def test_rejects_district_name_mismatch(self):
        self.assert_rejected(
            mutated(FIXTURE_507999, lambda f: f.__setitem__("district_name", "999999.bitmap"))
        )

    def test_rejects_invalid_snapshot_block_hash(self):
        self.assert_rejected(
            mutated(FIXTURE_507999, lambda f: f.__setitem__("snapshot_block_hash", "not-a-hash"))
        )

    def test_rejects_negative_sat(self):
        self.assert_rejected(mutated(FIXTURE_507999, lambda f: f.__setitem__("sat", -1)))

    def test_rejects_empty_candidates(self):
        self.assert_rejected(mutated(FIXTURE_507999, lambda f: f.__setitem__("candidates", [])))

    def test_rejects_missing_original_in_candidates(self):
        self.assert_rejected(
            mutated(FIXTURE_507999, lambda f: f.__setitem__("candidates", [f["candidates"][0]]))
        )

    def test_rejects_declared_content_mismatch(self):
        def mutate(f):
            f["candidates"][1]["declared_content"] = "other.bitmap"

        self.assert_rejected(mutated(FIXTURE_507999, mutate))

    def test_rejects_candidate_on_different_sat(self):
        def mutate(f):
            f["candidates"][0]["sat"] = 1

        self.assert_rejected(mutated(FIXTURE_507999, mutate))

    def test_rejects_inscription_id_position_mismatch(self):
        def mutate(f):
            f["candidates"][0]["canonical_position"]["inscription_index"] = 1

        self.assert_rejected(mutated(FIXTURE_507999, mutate))

    def test_rejects_missing_canonical_position(self):
        def mutate(f):
            del f["candidates"][0]["canonical_position"]

        self.assert_rejected(mutated(FIXTURE_507999, mutate))

    def test_rejects_negative_block_height(self):
        def mutate(f):
            f["candidates"][0]["canonical_position"]["block_height"] = -5

        self.assert_rejected(mutated(FIXTURE_507999, mutate))

    def test_rejects_duplicate_canonical_tuple(self):
        def mutate(f):
            f["candidates"][0]["canonical_position"] = dict(
                f["candidates"][1]["canonical_position"]
            )
            f["candidates"][0]["inscription_id"] = (
                f["candidates"][1]["canonical_position"]["transaction_id"] + "i0"
            )

        self.assert_rejected(mutated(FIXTURE_507999, mutate))

    def test_rejects_snapshot_height_candidate_wrong_block_hash(self):
        def mutate(f):
            f["candidates"][2]["canonical_position"]["block_hash"] = (
                "1" * 64
            )

        self.assert_rejected(mutated(FIXTURE_7187, mutate))

    def test_rejects_invalid_content_sha256(self):
        def mutate(f):
            f["candidates"][0]["content_sha256"] = "short"

        self.assert_rejected(mutated(FIXTURE_507999, mutate))

    def test_rejects_incomplete_enumeration(self):
        def mutate(f):
            f["candidate_enumeration"]["complete_through_snapshot"] = False

        self.assert_rejected(mutated(FIXTURE_507999, mutate))

    def test_rejects_enumeration_reporting_more_pages(self):
        def mutate(f):
            f["candidate_enumeration"]["reported_more"] = True

        self.assert_rejected(mutated(FIXTURE_507999, mutate))

    def test_rejects_enumeration_with_wrong_hash(self):
        def mutate(f):
            f["candidate_enumeration"]["response_sha256"] = "0" * 64

        self.assert_rejected(mutated(FIXTURE_507999, mutate))

    def test_rejects_enumeration_not_matching_candidates(self):
        def mutate(f):
            f["candidate_enumeration"]["response_body"] = '{"ids":["deadbeef"],"more":false,"page":0}'
            import hashlib

            f["candidate_enumeration"]["response_sha256"] = hashlib.sha256(
                f["candidate_enumeration"]["response_body"].encode("utf-8")
            ).hexdigest()

        self.assert_rejected(mutated(FIXTURE_507999, mutate))

    def test_rejects_ord_manifest_hash_mismatch(self):
        def mutate(f):
            f["source_manifest"]["ord"]["enumeration_response_sha256"] = "0" * 64

        self.assert_rejected(mutated(FIXTURE_507999, mutate))

    def test_rejects_opi_query_wrong_district(self):
        def mutate(f):
            f["source_manifest"]["opi"]["query"] = (
                "/v1/bitmap/get_inscription_id_of_bitmap?bitmap_number=1"
            )

        self.assert_rejected(mutated(FIXTURE_507999, mutate))

    def test_rejects_opi_manifest_inconsistent_status_and_hash(self):
        def mutate(f):
            f["source_manifest"]["opi"]["response_sha256"] = "a" * 64
            # response_status still claims "not_captured_..." -> inconsistent

        self.assert_rejected(mutated(FIXTURE_507999, mutate))

    def test_rejects_no_eligible_candidate_before_snapshot(self):
        def mutate(f):
            f["snapshot_height"] = 100
            f["snapshot_block_hash"] = "2" * 64

        self.assert_rejected(mutated(FIXTURE_507999, mutate))


class OutputShapeTests(unittest.TestCase):
    def test_output_is_json_serializable(self):
        result = resolve(FIXTURE_507999)
        json.dumps(result)  # must not raise

    def test_output_contains_all_required_fields(self):
        required = {
            "district",
            "original_inscription_id",
            "sat",
            "selected_inscription_id",
            "selected_content_sha256",
            "selected_canonical_position",
            "snapshot_height",
            "snapshot_block_hash",
            "candidate_count",
            "status",
            "scope",
            "warnings",
            "provenance",
        }
        result = resolve(FIXTURE_507999)
        self.assertTrue(required.issubset(result.keys()))


if __name__ == "__main__":
    unittest.main()
